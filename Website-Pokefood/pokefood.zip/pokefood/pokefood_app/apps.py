from django.apps import AppConfig


class PokefoodAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "pokefood_app"
